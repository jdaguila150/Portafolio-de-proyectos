package com.example.AcervoDeTeotihuacan;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class baja extends AppCompatActivity implements View.OnClickListener {
    EditText clave;
    TextView desc;
    Button bborra, bregre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baja);


        bborra=findViewById(R.id.bborrado);
        bborra.setOnClickListener(this);

        bregre=findViewById(R.id.bregresa);
        bregre.setOnClickListener(this);

        clave=findViewById(R.id.eclave);
        desc=findViewById(R.id.resultado);
    }

    @Override
    public void onClick(View v) {
        String cadenita = ((Button) v).getText().toString();
        if(cadenita.equals("BUSCAR")) {
            String descripcion;
            if (clave.equals("")){
                Toast.makeText(this, "Debes llenar todos los campos",Toast.LENGTH_SHORT).show();
            }
            else {
                Base admin = new Base(this, "administracion",
                        null, 1);
                SQLiteDatabase basededatos = admin.getReadableDatabase();
                String codigo = clave.getText().toString();
                Cursor fila = basededatos.rawQuery(
                        "select nombre, material1, material2, material3,tipo,lugar " +
                                "from pieza where clave =" +
                                codigo, null);
                if (fila.moveToFirst()) {
                    descripcion= "Nombre de la pieza: " +fila.getString(0) +
                            "\n Hecho con las materias primas de " + fila.getString(1) + "," +
                            fila.getString(2) + "," + fila.getString(3) + "," +
                            "\n encontrada en " + fila.getString(4) + " enfocada " + fila.getString(5)
                            + "\n Si esta seguro de eliminar, presione el boton.";
                    basededatos.close();
                    bborra.setText("BORRAR");
                } else {
                    descripcion ="PIEZA NO ENCONTRADO";
                }
                desc.setText(descripcion);
            }

        } else if(cadenita.equals("BORRAR")) {
            if (clave.equals("")){
                Toast.makeText(this, "Debes llenar todos los campos",Toast.LENGTH_SHORT).show();
            }
            else {
                Base admin = new Base(this, "administracion",
                        null, 1);
                SQLiteDatabase basededatos = admin.getReadableDatabase();
                String codigo = clave.getText().toString();
                int cantidad = basededatos.delete("pieza", "clave=" + codigo, null);
                desc.setText("");
                clave.setText("");
                Intent intet = new Intent(this, MainActivity.class);
                startActivity(intet);
                Toast.makeText(getApplicationContext(), "Se elimino", Toast.LENGTH_SHORT).show();
            }
        } else{
            Intent intet = new Intent(this, MainActivity.class);
            startActivity(intet);
        }
    }
}
