package com.example.AcervoDeTeotihuacan;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class alta extends AppCompatActivity implements View.OnClickListener {
    Button btSubir, btregre;
    EditText etclave, etnombre;
    Spinner Spgrupo;
    String[] pal = {"Selecciona opción.", "Para los reyes", "Para los esclavos"};
    String[] cam = {"Selecciona opción.", "Campesinos", "Plebeyos"};
    ArrayAdapter<String> ArOp;
    CheckBox obsi, cuarz, meta;
    RadioButton grup01, grup02;
    RadioGroup tipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alta);
        btSubir = findViewById(R.id.bsubir);
        btSubir.setOnClickListener(this);

        btregre = findViewById(R.id.bregresa);
        btregre.setOnClickListener(this);

        etclave = findViewById(R.id.eclave);
        etnombre = findViewById(R.id.enombre);

        Spgrupo = findViewById(R.id.cpertenece);

        tipo = findViewById(R.id.Rzonas);
        grup01 = findViewById(R.id.campo);
        grup02 = findViewById(R.id.palacio);

        obsi = findViewById(R.id.repMat1);
        cuarz = findViewById(R.id.repMat2);
        meta = findViewById(R.id.repMat3);
    }

    @Override
    public void onClick(View v) {
        String cadenita = ((Button) v).getText().toString();
        if (cadenita.equals("SUBIR")) {
            if (etclave.equals("") || etnombre.equals("")) {
                Toast.makeText(this, "Debes llenar todos los campos",
                        Toast.LENGTH_SHORT).show();
            } else {
                Base admin = new Base(this, "administracion", null, 1);
                SQLiteDatabase basededatos = admin.getWritableDatabase();
                ContentValues registro = new ContentValues();

                String Clave = etclave.getText().toString();
                String nombre = etnombre.getText().toString();

                registro.put("clave", Clave);
                registro.put("nombre", nombre);

                if (obsi.isChecked())
                    registro.put("material1", "Obsidiana");
                else
                    registro.put("material1", ".");
                if (cuarz.isChecked())
                    registro.put("material2", "Cuarzo");
                else
                    registro.put("material2", ".");
                if (meta.isChecked())
                    registro.put("material3", "Metate");
                else
                    registro.put("material3", ".");

                if (grup01.isChecked()) {
                    registro.put("tipo", "campo");
                    if (Spgrupo.getSelectedItemPosition() == 1) {
                        registro.put("lugar", "Campesinos");
                    } else {
                        registro.put("lugar", "Plebeyos");
                    }
                } else {
                    registro.put("tipo", "palacio");
                    if (Spgrupo.getSelectedItemPosition() == 1) {
                        registro.put("lugar", "Para_los_reyes");
                    } else {
                        registro.put("lugar", "Para_los_esclavos");
                    }
                }

                basededatos.insert("pieza", null, registro);
                basededatos.close();

                Toast.makeText(this, "Registro Hecho", Toast.LENGTH_SHORT).show();
                etclave.setText("");
                etnombre.setText("");
                Spgrupo.setSelection(0);
                obsi.setChecked(false);
                meta.setChecked(false);
                cuarz.setChecked(false);
                tipo.clearCheck();

                Intent intet = new Intent(this, MainActivity.class);
                startActivity(intet);
            }
        } else {
            Intent intet = new Intent(this, MainActivity.class);
            startActivity(intet);
        }
    }

    public void onRadioButtonClicked(View v) {
        String textito = ((RadioButton) v).getText().toString();
        if (textito.equals("Campo")) {
            ArOp = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, cam);
            Spgrupo.setAdapter(ArOp);
        } else {
            ArOp = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, pal);
            Spgrupo.setAdapter(ArOp);
        }
    }
}