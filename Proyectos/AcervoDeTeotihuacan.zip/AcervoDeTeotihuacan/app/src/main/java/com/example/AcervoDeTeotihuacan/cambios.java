package com.example.AcervoDeTeotihuacan;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class cambios extends AppCompatActivity implements View.OnClickListener {
    Button btSubir, btregre;
    EditText etclave, etnombre;
    Spinner Spgrupo;
    String[] pal = {"Selecciona opción.", "Para los reyes", "Para los esclavos"};
    String[] cam = {"Selecciona opción.", "Campesinos", "Plebeyos"};
    ArrayAdapter<String> ArOp;
    CheckBox obsi, cuarz, meta;
    RadioButton grup01, grup02;
    RadioGroup tipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cambios);
        btSubir = findViewById(R.id.bsubir);
        btSubir.setOnClickListener(this);

        btregre = findViewById(R.id.bregresa);
        btregre.setOnClickListener(this);

        etclave = findViewById(R.id.eclave);
        etnombre = findViewById(R.id.enombre);
        etnombre.setEnabled(false);

        Spgrupo = findViewById(R.id.cpertenece);
        Spgrupo.setEnabled(false);

        tipo = findViewById(R.id.Rzonas);
        grup01 = findViewById(R.id.campo);
        grup02 = findViewById(R.id.palacio);
        grup01.setEnabled(false);
        grup02.setEnabled(false);

        obsi = findViewById(R.id.repMat1);
        cuarz = findViewById(R.id.repMat2);
        meta = findViewById(R.id.repMat3);
        obsi.setEnabled(false);
        cuarz.setEnabled(false);
        meta.setEnabled(false);

        ArOp = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, pal);
        Spgrupo.setAdapter(ArOp);
    }

    @Override
    public void onClick(View v) {
        String cadenita = ((Button) v).getText().toString();
        if(cadenita.equals("BUSQUEDA")){
            if (etclave.equals("")){
                Toast.makeText(this, "Debes llenar todos los campos",Toast.LENGTH_SHORT).show();
            }
            else {
                Base admin = new Base(this, "administracion",
                        null, 1);
                SQLiteDatabase basededatos = admin.getReadableDatabase();
                String codigo = etclave.getText().toString();
                Cursor fila = basededatos.rawQuery(
                        "select nombre, material1, material2, material3,tipo,lugar " +
                                "from pieza where clave =" +
                                codigo, null);
                if (fila.moveToFirst()) {
                    etnombre.setEnabled(true);
                    etnombre.setText(fila.getString(0));

                    grup01.setEnabled(true);
                    grup02.setEnabled(true);
                    Spgrupo.setEnabled(true);
                    if(fila.getString(4).equals("campo")){
                        grup01.setChecked(true);
                    } else
                        grup02.setChecked(true);
                    if(fila.getString(5).equals("Plebeyos") || fila.getString(5).equals("Campesinos")){
                        Spgrupo.setSelection(1);
                    } else {
                        Spgrupo.setSelection(2);
                    }

                    obsi.setEnabled(true);
                    if(fila.getString(1).equals(".")){
                        obsi.setChecked(false);
                    } else {
                        obsi.setChecked(true);
                    }
                    cuarz.setEnabled(true);
                    if(fila.getString(2).equals(".")){
                        cuarz.setChecked(false);
                    } else {
                        meta.setChecked(true);
                    }
                    meta.setEnabled(true);
                    if(fila.getString(3).equals(".")){
                        meta.setChecked(false);
                    } else {
                        meta.setChecked(true);
                    }
                    basededatos.close();
                    btSubir.setText("ACTUALIZAR");
                }
            }
        } else if(cadenita.equals("ACTUALIZAR")){
            Base admin = new Base(this, "administracion", null, 1);
            SQLiteDatabase basededatos = admin.getWritableDatabase();
            ContentValues registro = new ContentValues();

            String Clave = etclave.getText().toString();
            String nombre = etnombre.getText().toString();

            registro.put("clave", Clave);
            registro.put("nombre", nombre);

            if (obsi.isChecked())
                registro.put("material1", "Obsidiana");
            else
                registro.put("material1", ".");
            if (cuarz.isChecked())
                registro.put("material2", "Cuarzo");
            else
                registro.put("material2", ".");
            if (meta.isChecked())
                registro.put("material3", "Metate");
            else
                registro.put("material3", ".");

            if (grup01.isChecked()) {
                registro.put("tipo", "campo");
                if (Spgrupo.getSelectedItemPosition() == 1) {
                    registro.put("lugar", "Campesinos");
                } else {
                    registro.put("lugar", "Plebeyos");
                }
            } else {
                registro.put("tipo", "palacio");
                if (Spgrupo.getSelectedItemPosition() == 1) {
                    registro.put("lugar", "Para los reyes");
                } else {
                    registro.put("lugar", "Para los esclavos");
                }
            }


            int cantidad = basededatos.update("pieza", registro, "clave=" + Clave, null);
            basededatos.close();
            if (cantidad == 1)
                Toast.makeText(this, "modificaciones correctas", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "debes llenar los campos", Toast.LENGTH_SHORT).show();

            etnombre.setEnabled(true);
            etnombre.setText("");
            grup01.setChecked(false);
            grup01.setEnabled(true);
            grup02.setChecked(false);
            grup02.setEnabled(true);
            Spgrupo.setEnabled(true);
            Spgrupo.setSelection(0);
            obsi.setEnabled(true);
            obsi.setChecked(false);
            cuarz.setEnabled(true);
            cuarz.setChecked(false);
            meta.setEnabled(true);
            meta .setChecked(false);
        } else {
            Intent intet = new Intent(this, MainActivity.class);
            startActivity(intet);
        }
    }


    public void onRadioButtonClicked(View v) {
        String textito = ((RadioButton) v).getText().toString();
        if (textito.equals("Campo")) {
            ArOp = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, cam);
            Spgrupo.setAdapter(ArOp);
        } else {
            ArOp = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, pal);
            Spgrupo.setAdapter(ArOp);
        }
    }
}