package com.example.AcervoDeTeotihuacan;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button baltas, bbajas, bconclav, bcambia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        baltas = findViewById(R.id.bagrega);
        baltas.setOnClickListener(this);

        bbajas = findViewById(R.id.bbajas);
        bbajas.setOnClickListener(this);

        bconclav = findViewById(R.id.bconsulta);
        bconclav.setOnClickListener(this);

        bcambia = findViewById(R.id.bcambia);
        bcambia.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String cadena = ((Button)v).getText().toString();
        if(cadena.equals("ALTAS")){
            Intent intet = new Intent(MainActivity.this, alta.class);
            startActivity(intet);
        } else if(cadena.equals("BAJAS")) {
            Intent intet = new Intent(MainActivity.this, baja.class);
            startActivity(intet);
        }else if(cadena.equals("CONSULTAS")) {
            Intent intet = new Intent(MainActivity.this, consultas.class);
            startActivity(intet);
        }
        else if(cadena.equals("CAMBIOS")) {
            Intent intet = new Intent(MainActivity.this, cambios.class);
            startActivity(intet);
        }
    }
}