package com.example.calc_cientifica;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tvResultado;
    float numero1 = 0.0f;
    float numero2 = 0.0f;
    double numero12;
    String operacion = "";
    Button btnPunto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResultado = findViewById(R.id.tvResultado);
        btnPunto = findViewById(R.id.btPunto);
    }
    public void EscribirZero(View view) {

        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("0");
        } else {
            tvResultado.setText(tvResultado.getText() + "0");
        }
    }
    public void EscribirUno(View view) {

        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("1");
        } else {
            tvResultado.setText(tvResultado.getText() + "1");
        }
    }
    public void EscribirDos(View view) {

        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("2");
        } else {
            tvResultado.setText(tvResultado.getText() + "2");
        }
    }
    public void EscribirTres(View view) {

        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("3");
        } else {
            tvResultado.setText(tvResultado.getText() + "3");
        }
    }
    public void EscribirCuatro(View view) {

        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("4");
        } else {
            tvResultado.setText(tvResultado.getText() + "4");
        }
    }
    public void EscribirCinco(View view) {

        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("5");
        } else {
            tvResultado.setText(tvResultado.getText() + "5");
        }
    }
    public void EscribirSeis(View view) {

        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("6");
        } else {
            tvResultado.setText(tvResultado.getText() + "6");
        }
    }
    public void EscribirSiete(View view) {
        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("7");
        } else {
            tvResultado.setText(tvResultado.getText() + "7");
        }
    }
    public void EscribirOcho(View view) {

        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("8");
        } else {
            tvResultado.setText(tvResultado.getText() + "8");
        }
    }
    public void EscribirNueve(View view) {

        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("9");
        } else {
            tvResultado.setText(tvResultado.getText() + "9");
        }
    }
    public void EscribirPunto(View view) {
        boolean punto = false;
        for (int i = 0; i < tvResultado.getText().toString().length(); i++) {
            if (tvResultado.getText().toString().charAt(i) == '.') {
                punto = false;
                break;
            } else {
                punto = true;
            }
        }
        if (punto == true) {
            tvResultado.setText(tvResultado.getText() + ".");
        }
    }
    public void Dividir(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        operacion = "/";
        tvResultado.setText("0");
    }
    public void Multiplicar(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        operacion = "*";
        tvResultado.setText("0");
    }
    public void Porcentaje(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        operacion = "%";
        tvResultado.setText("0");
    }
    public void Limpiar(View view) {
        tvResultado.setText("0");
        numero1 = 0.0f;
        numero2 = 0.0f;
        btnPunto.setEnabled(true);
    }
    public void Restar(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        operacion = "-";
        tvResultado.setText("0");
    }
    public void Sumar(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        operacion = "+";
        tvResultado.setText("0");
    }
    public void seno(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        double angulo = numero1;

        if (angulo > 0 && angulo < 90 ){
            double angulo1= Math.toRadians(numero1);
        tvResultado.setText(Math.sin(angulo1) + "");

        } else if (angulo > 90 && angulo < 180 ){
            angulo = 180 - angulo;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText(Math.sin(angulo1) + "");

        }else if (angulo > 180 && angulo < 270 ){
            angulo = angulo - 180;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText((Math.sin(angulo1)*(-1)) + "");

        }
        else if (angulo > 270 && angulo < 360 ){
            angulo = 360 - angulo;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText((Math.sin(angulo1)*(-1)) + "");

        }
        else if (angulo == 0){
            tvResultado.setText("0");
        }
        else if(angulo == 90){
            tvResultado.setText("1");
        }
        else if (angulo == 180){
            tvResultado.setText("0");
        }
        else if (angulo == 270){
            tvResultado.setText("-1");
        }
        else if(angulo == 360){
            tvResultado.setText("0");
        }


    }
    public void coseno(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        double angulo = numero1;

        if (angulo > 0 && angulo < 90 ){
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText(Math.cos(angulo1) + "");

        } else if (angulo > 90 && angulo < 180 ){
            angulo = 180 - angulo;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText((Math.cos(angulo1)*(-1)) + "");

        }else if (angulo > 180 && angulo < 270 ){
            angulo = angulo - 180;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText((Math.cos(angulo1)*(-1)) + "");

        }
        else if (angulo > 270 && angulo < 360 ){
            angulo = 360 - angulo;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText((Math.cos(angulo1)) + "");

        }
        else if (angulo == 0){
            tvResultado.setText("1");
        }
        else if(angulo == 90){
            tvResultado.setText("0");
        }
        else if (angulo == 180){
            tvResultado.setText("-1");
        }
        else if (angulo == 270){
            tvResultado.setText("0");
        }
        else if(angulo == 360){
            tvResultado.setText("1");
        }

    }
    public void tangente(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        double angulo = numero1;

        if (angulo > 0 && angulo < 90 ){
            double angulo1= Math.toRadians(numero1);
            tvResultado.setText(Math.tan(angulo1) + "");

        } else if (angulo > 90 && angulo < 180 ){
            angulo = 180 - angulo;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText((Math.tan(angulo1)*(-1)) + "");

        }else if (angulo > 180 && angulo < 270 ){
            angulo = angulo - 180;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText((Math.tan(angulo1)) + "");

        }
        else if (angulo > 270 && angulo < 360 ){
            angulo = 360 - angulo;
            double angulo1= Math.toRadians(angulo);
            tvResultado.setText((Math.tan(angulo1)*(-1)) + "");

        }

        else if (angulo == 0){
            tvResultado.setText("0");
        }
        else if(angulo == 90){
            tvResultado.setText("Error matematico");
        }
        else if (angulo == 180){
            tvResultado.setText("0");
        }
        else if (angulo == 270){
            tvResultado.setText("Error matematico");
        }
        else if(angulo == 360){
            tvResultado.setText("0");
        }

    }
    public void lognatural(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        tvResultado.setText(Math.log(numero1) + "");
    }
    public void potencia(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        operacion = "^";
        tvResultado.setText("0");
    }
    public void logaritmo(View view) {
        numero1 = Float.parseFloat(tvResultado.getText().toString());
        numero12 = Double.valueOf(numero1);
        tvResultado.setText(Math.log10(numero12) +"");

    }
    public void Masmenos(View view) {
        float valor = 0.0f;
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText(tvResultado.getText().toString());
        } else {
            valor = Float.parseFloat(tvResultado.getText().toString());
            valor = valor * (-1);

            tvResultado.setText(String.valueOf(valor));

        }
    }
    public void inverso(View view) {
        float valor = 0.0f;
        if (tvResultado.getText().toString().equals("0")) {
            tvResultado.setText("error");
        } else {
            valor = Float.parseFloat(tvResultado.getText().toString());
            valor = (float) Math.pow(valor, -1);

            tvResultado.setText(String.valueOf(valor));

        }
    }
    public void Resultado(View view) {
        numero2 = Float.parseFloat(tvResultado.getText().toString());
        if (operacion.equals("/")) {
            if (numero2 == 0.0f) {
                tvResultado.setText("0");
                Toast.makeText(this, "Operacion no valida", Toast.LENGTH_SHORT).show();
            } else {
                float resultado = numero1 / numero2;
                tvResultado.setText(resultado + "");
            }
        } else if (operacion.equals("*")) {
            float resultado = numero1 * numero2;
            tvResultado.setText(resultado + "");
            btnPunto.setEnabled(true);
        } else if (operacion.equals("%")) {
            float resultado = ((numero1 * numero2) / 100);
            tvResultado.setText(resultado + "");
            btnPunto.setEnabled(true);
        } else if (operacion.equals("-")) {
            float resultado = numero1 - numero2;
            tvResultado.setText(resultado + "");
            btnPunto.setEnabled(true);
        } else if (operacion.equals("+")) {
            float resultado = numero1 + numero2;
            tvResultado.setText(resultado + "");
            btnPunto.setEnabled(true);
        }else if (operacion.equals("^")) {
            double resultado = Math.pow(numero1,numero2);
            tvResultado.setText(resultado + "");
            btnPunto.setEnabled(true);
        }
    }
}