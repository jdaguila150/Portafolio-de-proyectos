//References
let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;
let answerr = false;

//Questions and Options array

const quizArray = [
    {
        id: "0",
        question: "¿Cómo te sientes al hablar en público?",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
    },
    {
        id: "1",
        question: "¿Qué tan a gusto estas contigo mismo?",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
    },
    {
        id: "2",
        question: "¿Cómo consideras que es tu calidad del sueño?",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
     },
    {
        id: "3",
        question: "¿Cómo consideras tus habilidades sociales?",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
     },
    {
        id: "4",
        question: "¿Cómo te sientes al despertar?",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
    },
    {
        id: "5",
        question: "¿Cómo es tu relación con tus amigos y familia?",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
      }, {
        id: "6",
        question: "Consideras que tus hábitos alimenticios, son:",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
      },
    {
        id: "7",
        question: "Consideras que tus metas, son:",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
     },
    {
        id: "8",
        question: "En los últimos días, como ha sido tu estado de ánimo:",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
       },
    {
        id: "9",
        question: "Si me veo al espejo, me siento:",
        options: ["Muy bien", 
        "Me es indiferente", 
        "No me gusta"],
        correct: "Muy bien", 
        medium:"Me es indiferente",
        bad:"No me gusta",
      },
];

//Restart Quiz
restart.addEventListener("click", () => {
    initial();
    displayContainer.classList.remove("hide");
    scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
    "click",
    (displayNext = () => {
        if(answerr == true){
			answerr = false;
        //increment questionCount
        questionCount += 1;
        //if last question
        if (questionCount == quizArray.length) {
            //hide question container and display score
            displayContainer.classList.add("hide");
            scoreContainer.classList.remove("hide");
            //user score

            if (scoreCount > 0 && scoreCount <= 16){
                userScore.innerHTML =
               // "Tienes depresion =( " + scoreCount + " respuestas correctas de " + questionCount;   
                "Sabemos que no estas en tu mejor momento, pero no te preocupes, todo es temporal. (resultados = depresión)"
            }
            else if (scoreCount >= 17  &&   scoreCount <= 33){
            userScore.innerHTML =
             //   "Tuviste ansiedad =) " + scoreCount + " respuestas correctas de " + questionCount;
                "Sabemos que no estas en tu mejor momento, pero no te preocupes, todo es temporal. (resultados = puede que sea depresión)"
            }
                else {
                userScore.innerHTML =
           //         "Tas bien " + scoreCount + " respuestas correctas de " + questionCount;
                "Estas Bien, pero no jamas dejes de cuidarte (resultados = favorables)"
                }
                
        } else {
            //display questionCount
            countOfQuestion.innerHTML =
                questionCount + 1 + " de " + quizArray.length + " preguntas";
            //display quiz
            quizDisplay(questionCount);
            count = 11;
            clearInterval(countdown);
            timerDisplay();
        }}
    })
);



//Display quiz
const quizDisplay = (questionCount) => {
    let quizCards = document.querySelectorAll(".container-mid");
    //Hide other cards
    quizCards.forEach((card) => {
        card.classList.add("hide");
    });
    //display current question card
    quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
    //randomly sort questions
    quizArray.sort(() => Math.random() - 0.5);
    //generate quiz
    for (let i of quizArray) {
        //randomly sort options
        i.options.sort(() => Math.random() - 0.5);
        //quiz card creation
        let div = document.createElement("div");
        div.classList.add("container-mid", "hide");
        //question number
        countOfQuestion.innerHTML = 1 + " de " + quizArray.length + " preguntas";
        //question
        let question_DIV = document.createElement("p");
        question_DIV.classList.add("question");
        question_DIV.innerHTML = i.question;
        div.appendChild(question_DIV);
        //options
        div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>

    `;
        quizContainer.appendChild(div);
    }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
    answerr = true;
    let userSolution = userOption.innerText;
    let question =
        document.getElementsByClassName("container-mid")[questionCount];
    let options = question.querySelectorAll(".option-div");

    //if user clicked answer == correct option stored in object
    if (userSolution === quizArray[questionCount].correct) {
        userOption.classList.add("correct");
        scoreCount = scoreCount + 5;
    } 
    else if(userSolution === quizArray[questionCount].medium){
        userOption.classList.add("medium");
        scoreCount = scoreCount + 3;
    }
    else if(userSolution === quizArray[questionCount].bad){
        userOption.classList.add("bad");
        scoreCount = scoreCount + 1;
    }
    else {
        userOption.classList.add("incorrect");
        scoreCount = scoreCount + 1;
    }

    //clear interval(stop timer)
    clearInterval(countdown);
    //disable all options
    options.forEach((element) => {
        element.disabled = true;
    });
}

//initial setup
function initial() {
    quizContainer.innerHTML = "";
    questionCount = 0;
    scoreCount = 0;
    count = 11;
    clearInterval(countdown);
    quizCreator();
    quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
    startScreen.classList.add("hide");
    displayContainer.classList.remove("hide");
    initial();
});

//hide quiz and display start screen
window.onload = () => {
    startScreen.classList.remove("hide");
    displayContainer.classList.add("hide");
};


//function iniciarCuestionario() {
//    startScreen.classList.add("hide");
//    displayContainer.classList.remove("hide");
//    initial();
//  }

//  iniciarCuestionario();    


