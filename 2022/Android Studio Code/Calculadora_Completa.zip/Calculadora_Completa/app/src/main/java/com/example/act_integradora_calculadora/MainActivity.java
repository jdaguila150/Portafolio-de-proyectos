package com.example.act_integradora_calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    Button bot;
    Button bot2;
    Button bot3;
    Button bot4;
    TextView tvox1;
    EditText edtext;
    EditText edtext2;
    Spinner spoperacions;

    String[] operaciones = {"Selecciona opcion","Suma","Resta","Multiplicacion","Division"};
    ArrayAdapter<String> aaoperaciones;

// LOS RADIO BOTONES
    private RadioGroup radioCalcGroup;
    private RadioButton bSuma, bRest, bMulti, bDiv;
    private Button botoncitoSalir;

    //SE GENERAN LOS BOTONES CON EL ACTION LISTENER
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bot = findViewById(R.id.botonSuma);
        bot.setOnClickListener(this);
        bot2 = findViewById(R.id.botonRest);
        bot2.setOnClickListener(this);
        bot3 = findViewById(R.id.botonMulti);
        bot3.setOnClickListener(this);
        bot4 = findViewById(R.id.botonDivision);
        bot4.setOnClickListener(this);
        tvox1 = findViewById(R.id.tv1);
        edtext = findViewById(R.id.edato);
        edtext2 = findViewById(R.id.edato2);

        //AÑADIMOS RADIO BOTONES

        bSuma = findViewById(R.id.rSuma);
        bSuma.setOnClickListener(this);

        bRest = findViewById(R.id.rResta);
        bRest.setOnClickListener(this);

        bDiv = findViewById(R.id.rDiv);
        bDiv.setOnClickListener(this);

        bMulti = findViewById(R.id.rMulti);
        bMulti.setOnClickListener(this);

        radioCalcGroup = findViewById(R.id.radioCalc);

        botoncitoSalir = findViewById(R.id.btnDisplay);
        botoncitoSalir.setOnClickListener(this);


        spoperacions = findViewById(R.id.combito);
        spoperacions.setOnItemSelectedListener(this);
        aaoperaciones = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, operaciones);
        spoperacions.setAdapter(aaoperaciones);

    }
    //SE LE DA A CADA BOTON SUS INTRUCCIONES PARA QUE DEN EL RESULTADO DESEADO
    @Override
    public void onClick(View v) {
        String text = ((Button) v).getText().toString();

        Clasesita numerito = new Clasesita();
        Clasesita numerito2 = new Clasesita();

        if (text.equals("Suma")) {
            numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
            numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));

            tvox1.setText(""  + (numerito.Suma() + numerito2.Suma2()));
            bot.setText("Suma");
        }
        else
            if (text.equals("Resta")) {
                numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                tvox1.setText(""  + (numerito.Resta() - numerito2.Resta2()));
                bot2.setText("Resta");
            }
            else
                if (text.equals("Multiplicacion")) {
                    numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                    numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                    tvox1.setText(""  + (numerito.Multiplicacion()*numerito2.Multiplicacion2()));
                    bot3.setText("Multiplicacion");
                }
                else
                    if (text.equals("Division")) {
                        numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                        numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                        tvox1.setText(""  + (numerito.Division()/numerito2.Division2()));
                        bot4.setText("Division");
                    }
                    else
                        if (v.getId() == R.id.rSuma) {
                            numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                            numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                            tvox1.setText(""  + (numerito.Suma() + numerito2.Suma2()));
                        }
                        else
                            if (v.getId() == R.id.rResta) {
                                numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                                numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                                tvox1.setText(""  + (numerito.Resta() - numerito2.Resta2()));
                            }
                            else
                                if (v.getId() == R.id.rMulti) {
                                    numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                                    numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                                    tvox1.setText(""  + (numerito.Multiplicacion()*numerito2.Multiplicacion2()));
                                }
                                else
                                    if (v.getId() == R.id.rDiv) {
                                        numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                                        numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                                        tvox1.setText(""  + (numerito.Division()/numerito2.Division2()));
                                    }
                                    else
                                        if (v.getId() == R.id.btnDisplay) {
                                            radioCalcGroup.clearCheck();
                                        }
    }



    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int seleccionado =spoperacions.getSelectedItemPosition();
        Clasesita numerito = new Clasesita();
        Clasesita numerito2 = new Clasesita();


        if (seleccionado > 0){

            numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
            numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));

            if(seleccionado == 1) {
                numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                tvox1.setText(""  + (numerito.Suma()+numerito2.Suma2()));

            }
            else
            if(seleccionado == 2) {
                numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                tvox1.setText(""  + (numerito.Resta()-numerito2.Resta2()));

            }
            else
            if(seleccionado == 3) {
                numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                tvox1.setText(""  + (numerito.Multiplicacion()*numerito2.Multiplicacion2()));

            }
            else
            if(seleccionado == 4) {
                numerito.setNumero1(Integer.parseInt(edtext.getText().toString()));
                numerito2.setNumero2(Integer.parseInt(edtext2.getText().toString()));
                tvox1.setText(""  + (numerito.Division()/numerito2.Division2()));

            }
        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {


    }

}
