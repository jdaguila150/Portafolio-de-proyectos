package com.example.areas_y_perimetros_actividades;

public class operaciones {

    public  String saludo1(){
        return("hola");
    }
    public  String saludo2(){
        return("hola nuevamente");
    }

}
