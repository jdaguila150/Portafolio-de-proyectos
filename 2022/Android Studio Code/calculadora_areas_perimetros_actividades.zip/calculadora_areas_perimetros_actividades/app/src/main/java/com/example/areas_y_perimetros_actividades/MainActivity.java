package com.example.areas_y_perimetros_actividades;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button botonrectangulo, botoncuadrado, botonciruclo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botoncuadrado = findViewById(R.id.bcuadrado);
        botoncuadrado.setOnClickListener(this);

        botonrectangulo = findViewById(R.id.brectangulo);
        botonrectangulo.setOnClickListener(this);

        botonciruclo = findViewById(R.id.bcirculo);
        botonciruclo.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        String cadena = ((Button) v).getText().toString();
        if(cadena.equals("cuadrado")){
            Intent intento2 = new Intent(this, cuadrado.class);
            startActivity(intento2);
        }
        else{
            if (cadena.equals("Rectangulo")){
                Intent intento3 = new Intent(this, rectangulo.class);
                startActivity(intento3);
            }
            else
                if (cadena.equals("Circulo")){
                    Intent intento4 = new Intent(this, circulo.class);
                    startActivity(intento4);
                }
        }

    }
}