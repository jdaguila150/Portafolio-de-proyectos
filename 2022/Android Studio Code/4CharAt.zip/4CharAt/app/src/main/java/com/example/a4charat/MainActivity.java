package com.example.a4charat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText Text1;
    TextView p;
    Button boton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text1= findViewById(R.id.Text1);
        p= findViewById(R.id.palabras);
        boton= findViewById(R.id.polindromo);

    }

    public void polindromo(View view) {
        String cad = Text1.getText().toString();
        String texto1 ="";
        boolean pol = false;

        for (int i = 0; i < cad.length(); i++){
            if(cad.charAt(i)==' '){}
            else
                texto1=texto1+cad.charAt(i);
        }
        for (int i = 0; i < texto1.length(); i++){
            if(texto1.charAt(i)==texto1.charAt(texto1.length()-i-1)){pol=true;}
            else
                pol=false;
        }
        if (pol==true){p.setText("Si es polindromo");}
        else
            p.setText("No es polindromo");
    }
}