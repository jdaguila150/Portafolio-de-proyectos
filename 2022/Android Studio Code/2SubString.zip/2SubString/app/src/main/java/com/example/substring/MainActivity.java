package com.example.substring;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText Text1;
    TextView p;
    Button boton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text1= findViewById(R.id.Text1);
        p= findViewById(R.id.palabras);
        boton= findViewById(R.id.buscar);

    }

    public void buscar(View view) {
        String cad = Text1.getText().toString();
        String texto ="";

        for (int i = 0; i < cad.length(); i++){
            if(cad.substring(i,i+1).equals(" ")){texto=texto+"\n";}
            else
                texto=texto+cad.substring(i,i+1);
        }
        p.setText(texto);
    }
}