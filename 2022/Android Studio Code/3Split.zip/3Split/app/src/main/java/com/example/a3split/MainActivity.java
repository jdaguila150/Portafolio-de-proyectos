package com.example.a3split;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.renderscript.Sampler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//String[] parts = string.split("Y");
public class MainActivity extends AppCompatActivity {

    EditText Text1;
    TextView p;
    Button boton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text1= findViewById(R.id.Text1);
        p= findViewById(R.id.palabras);
        boton= findViewById(R.id.separar);

    }

    public void separar(View view) {
        String cad = Text1.getText().toString();
        String [] text= cad.split(" ");
        String texto ="";

        for (int i = 0; i < text.length; i++){
            texto=texto+"\n"+text[i];
        }
        p.setText(texto);
    }
}