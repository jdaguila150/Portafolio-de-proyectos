package com.example.numsaletras;

public class metodos {
    String unidades [] = {
            "un", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete"
            ,"ocho", "nuevo"
    };
    String dieces [] = {
            "diez", "once", "doce","trece","catorce","quince","dieciseis","diecisiete","dieciocho",
            "diecinueve"
    };

    String veintenas [] = {
            "veinte","veintiuno","veintidos","veintitres","veinticuatro","veinticinco",
            "veintiseis","veintisiete","veintiocho","veintinueve",
    };
    String decenas [] = {
            "","diez","veinte","treinta","cuarenta","cincuenta","sesenta","setenta","ochenta",
            "noventa"
    };
    String cienasecas [] ={
            "cien"
    };
    String cientenas [] = {
            "ciento", "doscientos", "trescientos", "cuatrocientos" , "quinientos", "seiscientos"
            , "Setecientos", "ochosientos", "novecientos"
    };

    public String unacifra(int nume){
        String cadenita = "";
        String cadena = String.valueOf(nume);
        if (cadena.length()==1){
            cadenita = unidades[nume];
        }
        return cadenita;
    }
    public String doscifras (String textote){
        String solito = " ", cadenita = " ";
        solito = textote.substring(1,2);
        int numero = Integer.parseInt(solito);
        if (textote.substring(0,1).equals("1")){
            cadenita = dieces [numero];
        }
        else
            if (textote.substring(0,1).equals("2"))
                cadenita = veintenas[numero];
            else
                if (textote.substring(1,2).equals("0")){
                    int nume = Integer.parseInt((textote.substring(0,1)));
                    cadenita = decenas[nume];
                }
                else
                {
                    int numerito = Integer.parseInt(textote.substring(0,1));
                    int numerito2 = Integer.parseInt(textote.substring(1,2));
                    cadenita = decenas[numerito] + " y " + unidades[numerito2];
                }
        return cadenita;
    }
    public String trescifras (String textote){
        String solito = " ", cadenita = " ";
        solito = textote.substring(1,2);
        int numero = Integer.parseInt(solito);
        if (textote.substring(0,1).equals("100")){
            cadenita = cienasecas [numero];
        }
        else
            if (textote.substring())

        return cadenita;
    }
}
