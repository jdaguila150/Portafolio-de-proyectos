package com.example.numsaletras;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnKeyListener {

    EditText textito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        metodos met = new metodos();
        textito = findViewById(R.id.textito);
        textito.setOnKeyListener(this);
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        if (event.getAction()== KeyEvent.ACTION_UP) {
            String textote = textito.getText().toString();
            metodos met = new metodos();
            if (textote.length() == 1) {
                int numero = Integer.parseInt(textote);
                Toast.makeText(this, met.unacifra(numero), Toast.LENGTH_LONG).show();
            } else if (textote.length() == 2) {
                textote = textito.getText().toString();
                Toast.makeText(this, met.doscifras(textote), Toast.LENGTH_LONG).show();
            }
            else if (textote.length()==3){
                textote = textito.getText().toString();
                Toast.makeText(this, met.trescifras(textote), Toast.LENGTH_SHORT).show();
            }
        }
        return false;
    }
}